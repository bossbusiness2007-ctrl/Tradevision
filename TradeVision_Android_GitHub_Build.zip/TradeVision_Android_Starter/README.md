# TradeVision — prototype Android open source

Cette archive contient un **projet source de démarrage**, pas encore un APK compilé.

## Fonctionnalités du prototype
- Application Android avec WebView locale
- Interface sombre mobile
- Graphique en chandeliers basé sur TradingView Lightweight Charts
- Sélection d'instruments et d'unités de temps
- Affichage/masquage de EMA 9, EMA 21 et bandes de Bollinger
- Liste de marchés de démonstration

## Important
Les prix et chandeliers sont **simulés**. Aucune donnée de marché en direct, alerte système ou connexion MT5 n'est intégrée à ce prototype. Ne l'utilisez pas pour prendre des décisions financières.

Le code du graphique utilise Lightweight Charts via jsDelivr et nécessite une connexion Internet au premier chargement. Lightweight Charts est sous licence Apache 2.0 et demande une attribution à TradingView. Voir :
- https://www.tradingview.com/lightweight-charts/
- https://github.com/tradingview/lightweight-charts-android

## Compiler en APK
1. Installez Android Studio sur un ordinateur.
2. Décompressez cette archive.
3. Ouvrez le dossier `TradeVision_Android_Starter` dans Android Studio.
4. Laissez Gradle synchroniser le projet.
5. Choisissez **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio indiquera le chemin du fichier APK produit.

Configuration : minSdk 23 (Android 6.0 ou plus récent), compileSdk 35. Un JDK compatible avec la version d'Android Gradle Plugin est nécessaire.

## Prochaines étapes
1. Remplacer les données simulées par un fournisseur de données de marché avec conditions d'utilisation adaptées.
2. Implémenter RSI et d'autres indicateurs correctement.
3. Ajouter des outils de dessin, des alertes et un stockage des favoris.
4. Concevoir une intégration MT5 séparée et sécurisée.
5. Tester sur un appareil Android réel.

## Licence et attribution
Les fichiers propres à ce prototype sont fournis pour démarrage et adaptation. Lightweight Charts et ses composants restent soumis à leurs licences et notices respectives. L'application doit conserver l'attribution requise à TradingView.


## Compilation automatique sur GitHub
Le dossier `.github/workflows/android.yml` permet de compiler l'APK avec GitHub Actions.
Après avoir envoyé le contenu du projet dans le dépôt (pas le ZIP comme fichier unique), ouvrir l'onglet Actions et lancer « Build TradeVision APK ».
L'APK debug sera disponible dans les artefacts du workflow.
